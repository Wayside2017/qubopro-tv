QUBO PRO TV — NELVANA COLLECTION STARTER

Files:
- index.html: page structure
- styles.css: responsive styling
- script.js: searchable show catalog and details/video player

To use with GitHub:
1. Open your qubopro-tv repository.
2. Upload index.html, styles.css, and script.js to the repository root.
3. Commit the files.
4. Enable GitHub Pages in Settings > Pages, deploying from main / (root).

The catalog is a working list, not a verified exhaustive list of every Nelvana title that aired on Qubo. Confirm historical broadcast records before presenting it as complete.

The player accepts direct HTTP(S) MP4, WebM, or Ogg URLs for videos you own or are authorized to stream. No copyrighted episodes are included. This is an independent fan project, not affiliated with Qubo or Nelvana.
