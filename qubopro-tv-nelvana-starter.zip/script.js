// Working list of Nelvana-associated titles previously identified for this Qubo project.
// This is not a verified exhaustive broadcast list; confirm each title's Qubo run before labeling it definitive.
const nelvanaShows = [
  "Babar",
  "Babar and the Adventures of Badou",
  "Being Ian",
  "Class of the Titans",
  "Elliot Moose",
  "Franklin",
  "George and Martha",
  "Grossology",
  "Guess with Jess",
  "Inspector Gadget",
  "Jacob Two-Two",
  "Jane and the Dragon",
  "Maggie and the Ferocious Beast",
  "The Magic School Bus",
  "Marvin the Tap-Dancing Horse",
  "Mike the Knight",
  "Miss Spider's Sunny Patch Friends",
  "My Friend Rabbit",
  "Ned's Newt",
  "Pearlie",
  "Pecola",
  "Pippi Longstocking",
  "Rescue Heroes",
  "Rupert",
  "Scaredy Squirrel",
  "Sidekick",
  "Spliced",
  "Stickin' Around",
  "Super BOOMi",
  "Timothy Goes to School",
  "Willa's Wild Life"
];

const grid = document.querySelector("#show-grid");
const search = document.querySelector("#search");
const sort = document.querySelector("#sort");
const count = document.querySelector("#result-count");
const empty = document.querySelector("#empty");
const dialog = document.querySelector("#details");
const detailTitle = document.querySelector("#detail-title");
const detailCopy = document.querySelector("#detail-copy");
const player = document.querySelector("#player");
const videoForm = document.querySelector("#video-form");
const videoUrl = document.querySelector("#video-url");
let selectedShow = "";

function renderShows() {
  const query = search.value.trim().toLowerCase();
  const direction = sort.value;
  const filtered = nelvanaShows
    .filter(title => title.toLowerCase().includes(query))
    .sort((a, b) => direction === "az"
      ? a.localeCompare(b)
      : b.localeCompare(a));

  grid.replaceChildren();
  count.textContent = `${filtered.length} of ${nelvanaShows.length} titles`;

  filtered.forEach((title, index) => {
    const card = document.createElement("article");
    card.className = "show-card";

    const top = document.createElement("div");
    top.className = "card-top";
    top.innerHTML = `<span>NELVANA COLLECTION</span><span class="dot" aria-hidden="true"></span>`;

    const heading = document.createElement("h3");
    heading.textContent = title;

    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "View details";
    button.addEventListener("click", () => openShow(title));

    card.append(top, heading, button);
    grid.append(card);
  });

  empty.hidden = filtered.length !== 0;
}

function openShow(title) {
  selectedShow = title;
  detailTitle.textContent = title;
  detailCopy.textContent = "This title is part of the working Nelvana collection. Episode information and artwork can be added as they are verified. No episodes are supplied with this website.";
  videoUrl.value = "";
  showPlaceholder();
  dialog.showModal();
}

function showPlaceholder() {
  player.replaceChildren();
  const placeholder = document.createElement("div");
  placeholder.className = "player-placeholder";
  placeholder.innerHTML = '<span class="play">▶</span><b>No episode added</b><p>Add a direct video URL for content you own or are authorized to stream.</p>';
  player.append(placeholder);
}

videoForm.addEventListener("submit", event => {
  event.preventDefault();
  const url = videoUrl.value.trim();
  if (!url) return;
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") throw new Error();
    if (!/\.(mp4|webm|ogg)(\?.*)?$/i.test(parsed.pathname + parsed.search)) {
      alert("Please use a direct MP4, WebM, or Ogg video URL.");
      return;
    }
    const video = document.createElement("video");
    video.controls = true;
    video.playsInline = true;
    video.preload = "metadata";
    video.src = parsed.href;
    player.replaceChildren(video);
  } catch {
    alert("Enter a valid direct HTTP or HTTPS video URL.");
  }
});

document.querySelector("#close").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
});
search.addEventListener("input", renderShows);
sort.addEventListener("change", renderShows);
renderShows();
